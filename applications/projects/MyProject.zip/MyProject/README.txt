This is a blank project directory from which you can start developing a personal project.

You can create new classes in the lib subproject, while keeping your test executable in the exe subproject, so that your library can then be linked to SOFA without modifications.

========= Unix
To replace the project name "MyProject" with name "YourProject", type:
./changeProjectName YourProject

To compile it using the command line, do:
- qmake
- make

To run it from the command line, do:
LD_LIBRARY_PATH=../../../lib/linux:$LD_LIBRARY_PATH ../../../bin/runMyProject-latest 


Using kdevelop, the default working directory is the one which contains the executable, i.e. ../../../bin.
To change this you can adapt the run options, in menu Project>Project Options>Run options, as illustrated in image snap1.png in this directory.

=========== Windows
todo


=========== MacOS
todo
