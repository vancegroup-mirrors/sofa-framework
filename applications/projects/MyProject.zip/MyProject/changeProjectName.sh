#!/bin/sh

# Replace a project name.
# Arguments: OldProjectName NewProjectName
# This script:
# - replaces the old project name by the new project name in all the files, including subdirectories lib/ and exe/, using script changeClassName.sh

# number of arguments must be 2
if ! test $# -eq 1 
then
	echo arguments of changeProjectName: NewProjectName
	exit 1
fi

./changeClassName.sh MyProject $1;
cd lib; ../changeClassName.sh MyProject $1; 
cd ../exe; ../changeClassName.sh MyProject $1;
cd ../..; mv MyProject $1; 
echo project name changed from MyProject to $1

