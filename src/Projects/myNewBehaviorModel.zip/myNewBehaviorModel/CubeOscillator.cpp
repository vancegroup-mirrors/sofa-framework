#include "CubeOscillator.h"
#include <Sofa/Components/Common/ObjectFactory.h>
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/glut.h>
#include <math.h>

#include <iostream>
using std::cout;
using std::endl;

namespace Sofa
{

namespace Components
{

using namespace Common;


CubeOscillator::CubeOscillator()
        : Sofa::Abstract::BehaviorModel(), Sofa::Abstract::VisualModel()
        , cumulatedTime(0)
        , mean(1)
        , amplitude(1)
        , pulsation(6.28)
        , phase( 0 )
{}


CubeOscillator::~CubeOscillator()
{}

void CubeOscillator::setMean(double m)
{
    mean = m;
}
void CubeOscillator::setAmplitude(double a)
{
    amplitude=a;
}
void CubeOscillator::setPulsation(double w)
{
    pulsation=w;
}
void CubeOscillator::setPhase(double p)
{
    phase=p;
}


void CubeOscillator::init()
{
    cout<<"CubeOscillator::init "<< endl;
    cumulatedTime = 0;
}

void CubeOscillator::updatePosition( double dt )
{
    cout<<"CubeOscillator::updatePosition, dt = "<< dt << endl;
    cumulatedTime += dt;
}

void CubeOscillator::draw()
{
    cout<<"CubeOscillator::draw "<< endl;
    glScaled( mean + amplitude*sin(pulsation*cumulatedTime+phase),1.,1.);
    glutSolidCube( 2 );
}

void CubeOscillator::initTextures()
{
    cout<<"CubeOscillator::initTextures "<< endl;
}

void CubeOscillator::update()
{
    cout<<"CubeOscillator::update "<< endl;
}

void create(CubeOscillator*& obj, ObjectDescription* arg)
{
    cout<<"create(CubeOscillator*& obj, ObjectDescription*)"<< endl;
    obj = new CubeOscillator;
    if (arg->getAttribute("mean"))
        obj->setMean( atof(arg->getAttribute("mean")) );
    if (arg->getAttribute("amplitude"))
        obj->setAmplitude( atof(arg->getAttribute("amplitude")) );
    if (arg->getAttribute("pulsation"))
        obj->setPulsation( atof(arg->getAttribute("pulsation")) );
    if (arg->getAttribute("phase"))
        obj->setPhase( atof(arg->getAttribute("phase")) );

}

SOFA_DECL_CLASS(CubeOscillator)

Creator<ObjectFactory, CubeOscillator> CubeOscillatorClass("CubeOscillator");


}

}

