#include <iostream>
#include <fstream>
#include "argumentParser.h"
#include "Sofa/Components/Graph/Simulation.h"
#include "Sofa/Components/Common/Factory.h"
#ifdef SOFA_GUI_FLTK
#include "Sofa/GUI/FLTK/Main.h"
#endif
#ifdef SOFA_GUI_QT
#include "Sofa/GUI/QT/Main.h"
#endif


// ---------------------------------------------------------------------
// ---
// ---------------------------------------------------------------------
int main(int argc, char** argv)
{
	std::string fileName ;
	
        parse("This is a SOFA application. Here are the command line arguments")
	.option(&fileName,'f',"file","scene file")
	(argc,argv);


	Sofa::Components::Graph::GNode* groot = NULL; 

	if (!fileName.empty())
	{
		groot = Sofa::Components::Graph::Simulation::load(fileName.c_str());
	}
	else
	{
            groot = Sofa::Components::Graph::Simulation::load("../../../Data/demoDragon.scn");
	}

	if (groot==NULL)
	{
		groot = new Sofa::Components::Graph::GNode;
	}

	//=======================================
	// Run the main loop

#ifdef SOFA_GUI_FLTK
		Sofa::GUI::FLTK::MainLoop(argv[0],groot);
#endif
#ifdef SOFA_GUI_QT
		Sofa::GUI::QT::MainLoop(argv[0],groot,fileName.c_str());
#endif
	return 0;
}
