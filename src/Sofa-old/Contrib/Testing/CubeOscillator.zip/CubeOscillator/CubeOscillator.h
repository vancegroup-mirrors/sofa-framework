#ifndef Sofa_ComponentsCubeOscillator_h
#define Sofa_ComponentsCubeOscillator_h

#include <Sofa/Abstract/BehaviorModel.h>
#include <Sofa/Abstract/VisualModel.h>

namespace Sofa
{

namespace Components
{

/**
A simple example of Sofa "blackbox"
 
 
	@author Francois Faure, INRIA, Grenoble
*/
class CubeOscillator : public Sofa::Abstract::BehaviorModel, public Sofa::Abstract::VisualModel
{
public:
    CubeOscillator();

    ~CubeOscillator();

    /** @name BehaviorModel interface
    */
    ///@{
    virtual void init();

    /// Computation of a new simulation step.
    virtual void updatePosition(double dt);
    ///@}

    /** @name VisualModel interface
     */
    ///@{
    /// initialize the textures
    virtual void initTextures();

    /// display the VisualModel object.
    virtual void draw();

    /// used to compute the displacement of the model
    virtual void update();

    ///@}
    
    
    void setMean(double);
    void setAmplitude(double);
    void setPulsation(double);
    void setPhase(double);
    
    protected:
        double cumulatedTime;
        double mean;
        double amplitude;
        double pulsation;
        double phase;
};

}

}

#endif


