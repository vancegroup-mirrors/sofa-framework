#include "CubeOscillator.h"
#include <Sofa/Components/Common/ObjectFactory.h>
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/glut.h>
#include <math.h>

#include <iostream>
using std::cout;
using std::endl;

namespace Sofa
{

namespace Components
{

using namespace Common;


CubeOscillator::CubeOscillator()
        : Sofa::Abstract::BehaviorModel(), Sofa::Abstract::VisualModel()
        , cumulatedTime(0)
        , mean(1)
        , amplitude(1)
        , pulsation(6.28)
        , phase( 0 )
{
    addField(&mean,"mean","Mean value");
    addField(&amplitude,"amplitude","Amplitude of the function");
    addField(&pulsation,"pulsation","Pulstation of the function");
    addField(&phase,"phase","Phase of the function");
    addField(&fooVec,"fooVec","Just to test the vector fields");   
}


CubeOscillator::~CubeOscillator()
{}

void CubeOscillator::setMean(double m)
{
    mean = m;
}
void CubeOscillator::setAmplitude(double a)
{
    amplitude=a;
}
void CubeOscillator::setPulsation(double w)
{
    pulsation=w;
}
void CubeOscillator::setPhase(double p)
{
    phase=p;
}


void CubeOscillator::init()
{
    cout<<"CubeOscillator::init "<< endl;
    cumulatedTime = 0;
    writeFields(std::cout);
}

void CubeOscillator::updatePosition( double dt )
{
    cout<<"CubeOscillator::updatePosition, dt = "<< dt << endl;
    cumulatedTime += dt;
}

void CubeOscillator::draw()
{
    cout<<"CubeOscillator::draw "<< endl;
    glScaled( mean + amplitude*sin(pulsation*cumulatedTime+phase),1.,1.);
    glutSolidCube( 2 );
}

void CubeOscillator::initTextures()
{
    cout<<"CubeOscillator::initTextures "<< endl;
}

void CubeOscillator::update()
{
    cout<<"CubeOscillator::update "<< endl;
}

void create(CubeOscillator*& obj, ObjectDescription* arg)
{
    cout<<"create(CubeOscillator*& obj, ObjectDescription*)"<< endl;
    obj = new CubeOscillator;
    obj->parseFields( arg->getAttributeMap() );

}

SOFA_DECL_CLASS(CubeOscillator)

Creator<ObjectFactory, CubeOscillator> CubeOscillatorClass("CubeOscillator");


}

}

