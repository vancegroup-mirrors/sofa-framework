//
// C++ Interface: Field
//
// Description: 
//
//
// Author: The SOFA team </www.sofa-framework.org>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef Field_h
#define Field_h

#include <FieldBase.h>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <map>

typedef std::istringstream istrstream; 
typedef std::ostringstream ostrstream; 

namespace Sofa {

namespace Core {

/**
Pointer to data, readable and writable from/to a string.*/
template < class T = void* >
class Field : public Sofa::Core::FieldBase
{
public:
	/** Constructor
	\param t a pointer to the value
	\param ln long name of the argument
	\param h help on the argument
	\param m true iff the argument is mandatory
	*/
	Field( T* t, const char* h )
		: FieldBase(h)
		, ptr(t)
	{}
	
        inline void printValue(std::ostream& out) const ;
        inline std::string getValueString() const ;
	
private:
	/// Pointer to the parameter
	T* ptr;
	
	
	/** Try to read argument value from an input stream.
	    Return false if failed
	*/
	inline bool read( std::string& s ) {
		if (s.empty()) return false;
                //std::cerr<<"Field::read "<<s.c_str()<<std::endl;
		istrstream istr( s.c_str() );
                istr >> *ptr;
                if( istr.fail() ) {
                    //std::cerr<<"field "<<getName<<" could not read value: "<<s<<std::endl;
                    return false;
                }
		else {
			isSet = true;
			return true;
		}
	}

        ~Field(){}

};

/** Specialization for flag reading booleans. 
Booleans are seen as flags that you can set to TRUE using the command line.
Example: run --verbose
The advantage is that you do not have to set the value, it is automatically TRUE.
The drawback is that reading a boolean necessarily sets it to TRUE. Currently you can not set a boolean to FALSE using this parser.
*/
template<> inline 
bool Field<bool>::read( std::string& )
{
	*ptr = true;
	isSet = true;
	return true;
}

template<> inline 
        bool Field<std::string>::read( std::string& str )
{
	*ptr = str;
	isSet = true;
	return true;
}

/// General case for printing default value
template<class T> inline
        void Field<T>::printValue( std::ostream& out=std::cout ) const {
	out << *ptr << " ";
}

/// General case for printing default value
template<class T> inline
std::string Field<T>::getValueString() const 
{
    ostrstream out;
    out << *ptr;
    return out.str();
}


}

}

#endif
