#include "FieldContainer.h"

namespace Sofa
{

namespace Core
{

void  FieldContainer::parseFields ( std::list<std::string> str )
{
        string name;
        while( !str.empty() ) {
                name = str.front();
                str.pop_front();

                // field name
                if( m_fieldMap.find(name) != m_fieldMap.end() ) {
                        std::string s = str.front();
                        str.pop_front();
                        if( !(m_fieldMap[ name ]->read( s )))
                                std::cerr<< "\ncould not read value for option " << name <<": "<< s << std::endl << std::endl;
                } else
                        std::cerr << "\nUnknown option: " << name << std::endl << std::endl;
        }

}

void  FieldContainer::parseFields ( const std::map<std::string,std::string*>& args )
{
        // build  std::list<std::string> str
        using std::string;
        std::list<string> allAttributes;
        for( std::map<string,string*>::const_iterator i=args.begin(), iend=args.end(); i!=iend; i++ ) {
                allAttributes.push_back((*i).first);
                if( (*i).second!=NULL ) {
                        allAttributes.push_back(*(*i).second );
                }
        }

        // reuse parseFields(   std::list<std::string> str )
        parseFields( allAttributes );
}

void  FieldContainer::writeFields ( std::map<std::string,std::string*>& args )
{
        for( std::map<string,FieldBase*>::const_iterator a=m_fieldMap.begin(), aend=m_fieldMap.end(); a!=aend; ++a ) {
                string valueString;
                FieldBase* field = (*a).second;

                if( args[(*a).first] != NULL )
                    *args[(*a).first] = field->getValueString();
                else
                    args[(*a).first] =  new string(field->getValueString());
        }

}

void  FieldContainer::writeFields ( std::ostream& out )
{
        for( std::map<string,FieldBase*>::const_iterator a=m_fieldMap.begin(), aend=m_fieldMap.end(); a!=aend; ++a ) {
                FieldBase* field = (*a).second;
                out << (*a).first << " "<< field->getValueString() << "\n";
        }

}
}
}


