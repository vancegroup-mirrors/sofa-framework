//
// C++ Interface: FieldContainer
//
// Description:
//
//
// Author: The SOFA team </www.sofa-framework.org>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef FieldContainer_h
#define FieldContainer_h
#include "Field.h"
using std::string;

namespace Sofa
{

namespace Core
{

/**
Object which contains fields.
*/
class FieldContainer
{
protected:
        /// name -> Field object
        std::map< string, FieldBase* > m_fieldMap;

public:

        /** Declare a field
        \param ptr pointer to the variable
        \param name field name
        \param help
        */
        template<class T>
        inline
        FieldContainer& addField( T* ptr, char* name, char* help )
        {
                string ln(name);

                if( ln.size()>0 && m_fieldMap.find(ln) != m_fieldMap.end() ) {
                        std::cerr << "name " << ln << " already used !" << std::endl;
                        exit( 1 );
                }

                FieldBase* c = new Field<T>(ptr,help);
                m_fieldMap[name] = c;
                return (*this);
        }


        void parseFields ( std::list<std::string> str );
        void parseFields ( const std::map<std::string,std::string*>& str );
        void writeFields (std::map<std::string,std::string*>& str);
        void writeFields (std::ostream& out);
};
}
}
#endif

